package com.traynotifications.animations;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

// AnimationProvider class to manage a list of TrayAnimation objects
public class AnimationProvider {

    // List to store the TrayAnimation objects
    private List<TrayAnimation> animationsList;

    // Constructor that takes a variable number of TrayAnimation objects
    public AnimationProvider(TrayAnimation... animations) {
        // Initialize the list
        animationsList = new ArrayList<>();
        // Add all the provided animations to the list
        Collections.addAll(animationsList, animations);
    }

    // Method to add a variable number of TrayAnimation objects to the list
    public void addAll(TrayAnimation... animations) {
        Collections.addAll(animationsList, animations);
    }

    // Method to get a TrayAnimation object from the list by its index
    public TrayAnimation get(int index) {
        return animationsList.get(index);
    }

    // Method to find the first TrayAnimation object in the list that matches a given predicate
    public TrayAnimation findFirstWhere(Predicate<? super TrayAnimation> predicate) {
        return animationsList.stream().filter(predicate).findFirst().orElse(null);
    }

    // Method to get a list of TrayAnimation objects that match a given predicate
    public List<TrayAnimation> where(Predicate<? super TrayAnimation> predicate) {
        return animationsList.stream().filter(predicate).collect(Collectors.toList());
    }
}