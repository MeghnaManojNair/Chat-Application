// Importing necessary packages and classes
package com.traynotifications.notification;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.stage.StageStyle;
import javafx.util.Duration;
import com.traynotifications.animations.*;
import com.traynotifications.models.CustomStage;

import java.io.IOException;
import java.net.URL;

// Notification class for displaying tray notifications
public final class TrayNotification {

    // FXML annotations for injecting UI components
    @FXML
    private Label lblTitle, lblMessage, lblClose;
    @FXML
    private ImageView imageIcon;
    @FXML
    private Rectangle rectangleColor;
    @FXML
    private AnchorPane rootNode;

    private CustomStage stage;
    private NotificationType notificationType;
    private AnimationType animationType;
    private EventHandler<ActionEvent> onDismissedCallBack, onShownCallback;
    private TrayAnimation animator;
    private AnimationProvider animationProvider;

    // Constructor for custom tray notification
    public TrayNotification(String title, String body, Image img, Paint rectangleFill) {
        initTrayNotification(title, body, NotificationType.CUSTOM);

        setImage(img);
        setRectangleFill(rectangleFill);
    }

    // Constructor for predefined tray notification types
    public TrayNotification(String title, String body, NotificationType notificationType ) {
        initTrayNotification(title, body, notificationType);
    }

    // Default constructor
    public TrayNotification() {
        initTrayNotification("", "", NotificationType.CUSTOM);
    }

    // Initializes the tray notification
    private void initTrayNotification(String title, String message, NotificationType type) {

        try {
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("/views/TrayNotification.fxml"));

            fxmlLoader.setController(this);
            fxmlLoader.load();

            initStage();
            initAnimations();

            setTray(title, message, type);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Initializes animation provider
    private void initAnimations() {

        animationProvider =
            new AnimationProvider(new FadeAnimation(stage), new SlideAnimation(stage), new PopupAnimation(stage));

        // Default animation type
        setAnimationType(AnimationType.SLIDE);
    }

    // Initializes the custom stage
    private void initStage() {

        stage = new CustomStage(rootNode, StageStyle.UNDECORATED);
        stage.setScene(new Scene(rootNode));
        stage.setAlwaysOnTop(true);
        stage.setLocation(stage.getBottomRight());

        lblClose.setOnMouseClicked(e -> dismiss());
    }

    // Sets the notification type
    public void setNotificationType(NotificationType nType) {

        notificationType = nType;

        URL imageLocation = null;
        String paintHex = null;

        switch (nType) {

            case INFORMATION:
                imageLocation = getClass().getResource("/tray/resources/info.png");
                paintHex = "#e07a5f";
                break;

            case NOTICE:
                imageLocation = getClass().getResource("/tray/resources/notice.png");
                paintHex = "#f4f1de";
                break;

            case SUCCESS:
                imageLocation = getClass().getResource("/tray/resources/success.png");
                paintHex = "#3d405b";
                break;

            case WARNING:
                imageLocation = getClass().getResource("/tray/resources/warning.png");
                paintHex = "#81b29a";
                break;

            case ERROR:
                imageLocation = getClass().getResource("/tray/resources/error.png");
                paintHex = "#f2cc8f";
                break;

            case CUSTOM:
                return;
        }

        setRectangleFill(Paint.valueOf(paintHex));
        setImage(new Image(imageLocation.toString()));
        setTrayIcon(imageIcon.getImage());
    }

    // Gets the notification type
    public NotificationType getNotificationType() {
        return notificationType;
    }

    // Sets the tray notification content
    public void setTray(String title, String message, NotificationType type) {
        setTitle(title);
        setMessage(message);
        setNotificationType(type);
    }

    // Sets the tray notification content with additional parameters
    public void setTray(String title, String message, Image img, Paint rectangleFill, AnimationType animType) {
        setTitle(title);
        setMessage(message);
        setImage(img);
        setRectangleFill(rectangleFill);
        setAnimationType(animType);
    }

    // Checks if the tray notification is currently showing
    public boolean isTrayShowing() {
        return animator.isShowing();
    }

    // Shows the tray notification with a delay for dismissal
    public void showAndDismiss(Duration dismissDelay) {

        if (isTrayShowing()) {
            dismiss();
        } else {
            stage.show();

            onShown();
            animator.playSequential(dismissDelay);
        }

        onDismissed();
    }

    // Shows the tray notification and waits for dismissal
    public void showAndWait() {

        if (! isTrayShowing()) {
            stage.show();

            animator.playShowAnimation();

            onShown();
        }
    }

    // Dismisses the tray notification
    public void dismiss() {

        if (isTrayShowing()) {
            animator.playDismissAnimation();
            onDismissed();
        }
    }

    // Handles the on shown event
    private void onShown() {
        if (onShownCallback != null)
            onShownCallback.handle(new ActionEvent());
    }

    // Handles the on dismissed event
    private void onDismissed() {
        if (onDismissedCallBack != null)
            onDismissedCallBack.handle(new ActionEvent());
    }

    // Sets the on dismiss event handler
    public void setOnDismiss(EventHandler<ActionEvent> event) {
        onDismissedCallBack  = event;
    }

    // Sets the on shown event handler
    public void setOnShown(EventHandler<ActionEvent> event) {
        onShownCallback  = event;
    }

    // Sets the tray icon
    public void setTrayIcon(Image img) {
        stage.getIcons().clear();
        stage.getIcons().add(img);
    }

    // Gets the tray icon
    public Image getTrayIcon() {
        return stage.getIcons().get(0);
    }

    // Sets the title of the tray notification
    public void setTitle(String txt) {
        lblTitle.setText(txt);
    }

    // Gets the title of the tray notification
    public String getTitle() {
        return lblTitle.getText();
    }

    // Sets the message of the tray notification
    public void setMessage(String txt) {
        lblMessage.setText(txt);
    }

    // Gets the message of the tray notification
    public String getMessage() {
        return lblMessage.getText();
    }

    // Sets the image of the tray notification
    public void setImage (Image img) {
        imageIcon.setImage(img);

        setTrayIcon(img);
    }

    // Gets the image of the tray notification
    public Image getImage() {
        return imageIcon.getImage();
    }

    // Sets the fill color of the tray notification rectangle
    public void setRectangleFill(Paint value) {
        rectangleColor.setFill(value);
    }

    // Gets the fill color of the tray notification rectangle
    public Paint getRectangleFill() {
        return

 rectangleColor.getFill();
    }

    // Sets the animation type of the tray notification
    public void setAnimationType(AnimationType type) {
        animator = animationProvider.findFirstWhere(a -> a.getAnimationType() == type);

        animationType = type;
    }

    // Gets the animation type of the tray notification
    public AnimationType getAnimationType() {
        return animationType;
    }
}
