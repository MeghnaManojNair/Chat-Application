package com.traynotifications.animations;

import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.SequentialTransition;
import javafx.animation.Timeline;
import javafx.util.Duration;
import com.traynotifications.models.CustomStage;

// FadeAnimation class implements TrayAnimation for fade in and fade out animations
public class FadeAnimation implements TrayAnimation {

    // Timelines for show and dismiss animations
    private final Timeline showAnimation, dismissAnimation;
    // SequentialTransition for playing animations sequentially
    private final SequentialTransition sq;
    // CustomStage object for the stage to be animated
    private final CustomStage stage;
    // Boolean flag to track if the tray is showing
    private boolean trayIsShowing;

    // Constructor that takes a CustomStage object
    public FadeAnimation(CustomStage customStage) {
        // Initialize the stage, showAnimation, dismissAnimation, and sq
        this.stage = customStage;
        showAnimation = setupShowAnimation();
        dismissAnimation = setupDismissAnimation();
        sq = new SequentialTransition(setupShowAnimation(), setupDismissAnimation());
    }

    // Method to setup the show animation
    private Timeline setupShowAnimation() {
        // Create a new Timeline
        Timeline tl = new Timeline();
        // Create KeyValues for the opacity property of the stage
        KeyValue kvOpacity = new KeyValue(stage.opacityProperty(), 0.0);
        KeyFrame frame1 = new KeyFrame(Duration.ZERO, kvOpacity);
        KeyValue kvOpacity2 = new KeyValue(stage.opacityProperty(), 1.0);
        KeyFrame frame2 = new KeyFrame(Duration.millis(4000), kvOpacity2);
        // Add the KeyFrames to the Timeline
        tl.getKeyFrames().addAll(frame1, frame2);
        // Set the onFinished event handler for the Timeline
        tl.setOnFinished(e -> trayIsShowing = true);
        // Return the Timeline
        return tl;
    }

    // Method to setup the dismiss animation
    private Timeline setupDismissAnimation() {
        // Create a new Timeline
        Timeline tl = new Timeline();
        // Create a KeyValue for the opacity property of the stage
        KeyValue kv1 = new KeyValue(stage.opacityProperty(), 0.0);
        KeyFrame kf1 = new KeyFrame(Duration.millis(3000), kv1);
        // Add the KeyFrame to the Timeline
        tl.getKeyFrames().addAll(kf1);
        // Set the onFinished event handler for the Timeline
        tl.setOnFinished(e -> {
            trayIsShowing = false;
            stage.close();
            stage.setLocation(stage.getBottomRight());
        });
        // Return the Timeline
        return tl;
    }

    // Method to get the animation type
    @Override
    public AnimationType getAnimationType() {
        return AnimationType.FADE;
    }

    // Method to play the animations sequentially
    @Override
    public void playSequential(Duration dismissDelay) {
        sq.getChildren().get(1).setDelay(dismissDelay);
        sq.play();
    }

    // Method to play the show animation
    @Override
    public void playShowAnimation() {
        showAnimation.play();
    }

    // Method to play the dismiss animation
    @Override
    public void playDismissAnimation() {
        dismissAnimation.play();
    }

    // Method to check if the tray is showing
    @Override
    public boolean isShowing() {
        return trayIsShowing;
    }
}