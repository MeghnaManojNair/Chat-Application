package com.traynotifications.models;

import javafx.beans.property.SimpleDoubleProperty;
import javafx.geometry.Rectangle2D;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Screen;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

// CustomStage class extends Stage for custom stage settings
public class CustomStage extends Stage {

    // Location object for the bottom right of the stage
    private final Location bottomRight;

    // Constructor that takes an AnchorPane and StageStyle
    public CustomStage(AnchorPane ap, StageStyle style) {
        // Initialize the stage style
        initStyle(style);

        // Set the size of the stage
        setSize(ap.getPrefWidth(), ap.getPrefHeight());

        // Get the screen bounds
        Rectangle2D screenBounds = Screen.getPrimary().getVisualBounds();
        // Calculate the x and y coordinates for the bottom right of the stage
        double x = screenBounds.getMinX() + screenBounds.getWidth() - ap.getPrefWidth() - 2;
        double y = screenBounds.getMinY() + screenBounds.getHeight() - ap.getPrefHeight() - 2;

        // Initialize the bottomRight location
        bottomRight = new Location(x,y);
    }

    // Method to get the bottom right location of the stage
    public Location getBottomRight() {
        return bottomRight;
    }

    // Method to set the size of the stage
    public void setSize(double width, double height) {
        setWidth(width);
        setHeight(height);
    }

    // Method to get the off screen bounds of the stage
    public Location getOffScreenBounds() {
        Location loc = getBottomRight();

        return new Location(loc.getX() + this.getWidth(), loc.getY());
    }

    // Method to set the location of the stage
    public void setLocation(Location loc) {
        setX(loc.getX());
        setY(loc.getY());
    }

    // SimpleDoubleProperty for the x location of the stage
    private SimpleDoubleProperty xLocationProperty = new SimpleDoubleProperty() {
        @Override
        public void set(double newValue) {
            setX(newValue);
        }

        @Override
        public double get() {
            return getX();
        }
    };

    // Method to get the x location property of the stage
    public SimpleDoubleProperty xLocationProperty() {
        return xLocationProperty;
    }

    // SimpleDoubleProperty for the y location of the stage
    private SimpleDoubleProperty yLocationProperty = new SimpleDoubleProperty() {
        @Override
        public void set(double newValue) {
            setY(newValue);
        }

        @Override
        public double get() {
            return getY();
        }
    };

    // Method to get the y location property of the stage
    public SimpleDoubleProperty yLocationProperty() {
        return yLocationProperty;
    }
}