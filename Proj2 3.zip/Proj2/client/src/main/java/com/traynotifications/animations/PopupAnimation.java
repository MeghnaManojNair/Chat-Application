package com.traynotifications.animations;

import javafx.animation.*;
import com.traynotifications.models.CustomStage;
import javafx.util.Duration;

// PopupAnimation class implements TrayAnimation for popup animations
public class PopupAnimation implements TrayAnimation {

    // Timelines for show and dismiss animations
    private final Timeline showAnimation, dismissAnimation;
    // SequentialTransition for playing animations sequentially
    private final SequentialTransition sq;
    // CustomStage object for the stage to be animated
    private final CustomStage stage;
    // Boolean flag to track if the tray is showing
    private boolean trayIsShowing;

    // Constructor that takes a CustomStage object
    public PopupAnimation(CustomStage s) {
        // Initialize the stage, showAnimation, dismissAnimation, and sq
        this.stage = s;
        showAnimation = setupShowAnimation();
        dismissAnimation = setupDismissAnimation();
        sq = new SequentialTransition(setupShowAnimation(), setupDismissAnimation());
    }

    // Method to setup the dismiss animation
    private Timeline setupDismissAnimation() {
        // Create a new Timeline
        Timeline tl = new Timeline();
        // Create KeyValues for the yLocation and opacity properties of the stage
        KeyValue kv1 = new KeyValue(stage.yLocationProperty(), stage.getY() + stage.getWidth());
        KeyFrame kf1 = new KeyFrame(Duration.millis(2000), kv1);
        KeyValue kv2 = new KeyValue(stage.opacityProperty(), 0.0);
        KeyFrame kf2 = new KeyFrame(Duration.millis(2000), kv2);
        // Add the KeyFrames to the Timeline
        tl.getKeyFrames().addAll(kf1, kf2);
        // Set the onFinished event handler for the Timeline
        tl.setOnFinished(e -> {
            trayIsShowing = false;
            stage.close();
            stage.setLocation(stage.getBottomRight());
        });
        // Return the Timeline
        return tl;
    }

    // Method to setup the show animation
    private Timeline setupShowAnimation() {
        // Create a new Timeline
        Timeline tl = new Timeline();
        // Create KeyValues for the yLocation and opacity properties of the stage
        KeyValue kv1 = new KeyValue(stage.yLocationProperty(), stage.getBottomRight().getY() + stage.getWidth());
        KeyFrame kf1 = new KeyFrame(Duration.ZERO, kv1);
        KeyValue kv2 = new KeyValue(stage.yLocationProperty(), stage.getBottomRight().getY());
        KeyFrame kf2 = new KeyFrame(Duration.millis(1000), kv2);
        KeyValue kv3 = new KeyValue(stage.opacityProperty(), 0.0);
        KeyFrame kf3 = new KeyFrame(Duration.ZERO, kv3);
        KeyValue kv4 = new KeyValue(stage.opacityProperty(), 1.0);
        KeyFrame kf4 = new KeyFrame(Duration.millis(2000), kv4);
        // Add the KeyFrames to the Timeline
        tl.getKeyFrames().addAll(kf1, kf2, kf3, kf4);
        // Set the onFinished event handler for the Timeline
        tl.setOnFinished(e -> trayIsShowing = true);
        // Return the Timeline
        return tl;
    }

    // Method to get the animation type
    @Override
    public AnimationType getAnimationType() {
        return AnimationType.POPUP;
    }

    // Method to play the animations sequentially
    @Override
    public void playSequential(Duration dismissDelay) {
        sq.getChildren().get(1).setDelay(dismissDelay);
        sq.play();
    }

    // Method to play the show animation
    @Override
    public void playShowAnimation() {
        showAnimation.play();
    }

    // Method to play the dismiss animation
    @Override
    public void playDismissAnimation() {
        dismissAnimation.play();
    }

    // Method to check if the tray is showing
    @Override
    public boolean isShowing() {
        return trayIsShowing;
    }
}