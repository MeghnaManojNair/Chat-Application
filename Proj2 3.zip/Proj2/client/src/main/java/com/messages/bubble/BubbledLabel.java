package com.messages.bubble;

import javafx.beans.InvalidationListener;
import javafx.beans.Observable;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.paint.Color;
import javafx.scene.shape.Shape;

// BubbledLabel class extends the Label class to create a custom label with a bubble around it
public class BubbledLabel extends Label {
	// BubbleSpec enum to determine the type of bubble to draw
	private BubbleSpec bs = BubbleSpec.FACE_LEFT_CENTER;
	// Padding for the label
	private double pading = 5.0;
	// Flag to check if the change was made by the system
	private boolean systemCall = false;

	// Default constructor
	public BubbledLabel() {
		super();
		init();
	}

	// Constructor with text and graphic
	public BubbledLabel(String arg0, Node arg1) {
		super(arg0, arg1);
		init();
	}

	// Constructor with text
	public BubbledLabel(String arg0) {
		super(arg0);
		init();
	}

	// Constructor with BubbleSpec
	public BubbledLabel(BubbleSpec bubbleSpec) {
		super();
		this.bs = bubbleSpec;
		init();
	}

	// Constructor with text, graphic, and BubbleSpec
	public BubbledLabel(String arg0, Node arg1,BubbleSpec bubbleSpec) {
		super(arg0, arg1);
		this.bs = bubbleSpec;
		init();
	}

	// Constructor with text and BubbleSpec
	public BubbledLabel(String arg0,BubbleSpec bubbleSpec) {
		super(arg0);
		this.bs = bubbleSpec;
		init();
	}

	// Initialization method
	private void init(){
		// Create a drop shadow effect
		DropShadow ds = new DropShadow();
		ds.setOffsetX(1.3);
		ds.setOffsetY(1.3);
		ds.setColor(Color.DARKGRAY);
		// Set the preferred size of the label
		setPrefSize(Label.USE_COMPUTED_SIZE, Label.USE_COMPUTED_SIZE);
		// Add a listener to the shape property
		shapeProperty().addListener(new ChangeListener<Shape>() {
			@Override
			public void changed(ObservableValue<? extends Shape> arg0,
					Shape arg1, Shape arg2) {
				if(systemCall){					
					systemCall = false;
				}else{
					shapeIt();
				}
			}
		});

		// Add a listener to the height property
		heightProperty().addListener(new InvalidationListener() {

			@Override
			public void invalidated(Observable arg0) {
				if(!systemCall)
					setPrefHeight(Label.USE_COMPUTED_SIZE);
			}
		});

		// Add a listener to the width property
		widthProperty().addListener(new InvalidationListener() {

			@Override
			public void invalidated(Observable observable) {
				if(!systemCall)
					setPrefHeight(Label.USE_COMPUTED_SIZE);
			}
		});

		// Shape the label
		shapeIt();		
	}

	// Method to update the bounds of the label
	@Override
	protected void updateBounds() {
		super.updateBounds();		
		switch (bs) {
		case FACE_LEFT_BOTTOM:
			setPadding(new Insets(pading,pading,
					(this.getBoundsInLocal().getWidth()*((Bubble)getShape()).drawRectBubbleIndicatorRule)/2
					+pading,
					pading));
			break;
		case FACE_LEFT_CENTER:
			setPadding(new Insets(pading,pading,pading,
					(this.getBoundsInLocal().getWidth()*((Bubble)getShape()).drawRectBubbleIndicatorRule)/2
					+pading
					));
			break;
		case FACE_RIGHT_BOTTOM:
			setPadding(new Insets(pading,
					(this.getBoundsInLocal().getWidth()*((Bubble)getShape()).drawRectBubbleIndicatorRule)/2
					+pading
					,pading,pading));
			break;
		case FACE_RIGHT_CENTER:
			setPadding(new Insets(pading,
					(this.getBoundsInLocal().getWidth()*((Bubble)getShape()).drawRectBubbleIndicatorRule)/2
					+pading
					,pading,pading));
			break;
		case FACE_TOP:
			setPadding(new Insets(
					(this.getBoundsInLocal().getWidth()*((Bubble)getShape()).drawRectBubbleIndicatorRule)/2
					+pading,
					pading,pading,pading));
			break;

		default:
			break;
		}
	}

	// Getter for padding
	public final double getPading() {
		return pading;
	}

	// Setter for padding
	public void setPading(double pading) {
		if(pading > 25.0)
			return;
		this.pading = pading;
	}

	// Getter for BubbleSpec
	public BubbleSpec getBubbleSpec() {
		return bs;
	}

	// Setter for BubbleSpec
	public void setBubbleSpec(BubbleSpec bubbleSpec) {
		this.bs = bubbleSpec;
		shapeIt();
	}

	// Method to shape the label
	private final void shapeIt(){
		systemCall = true;
		setShape(new Bubble(bs));
		System.gc();
	}
}

