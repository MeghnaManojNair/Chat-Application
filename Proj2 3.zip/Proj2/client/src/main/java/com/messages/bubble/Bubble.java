package com.messages.bubble;

import javafx.scene.shape.HLineTo;
import javafx.scene.shape.LineTo;
import javafx.scene.shape.MoveTo;
import javafx.scene.shape.Path;
import javafx.scene.shape.VLineTo;

// Bubble class extends the Path class to create a custom shape
public class Bubble extends Path{

	// Constructor takes a BubbleSpec enum to determine the type of bubble to draw
	public Bubble(BubbleSpec bubbleSpec) {
		super();
		switch (bubbleSpec) {
		case FACE_BOTTOM:
			// No action taken for FACE_BOTTOM
			break;
		case FACE_LEFT_BOTTOM:
			// Draw a rectangle bubble with the baseline indicator on the left
			drawRectBubbleLeftBaselineIndicator();
			break;
		case FACE_LEFT_CENTER:
			// Draw a rectangle bubble with the center indicator on the left
			drawRectBubbleLeftCenterIndicator();
			break;
		case FACE_RIGHT_BOTTOM:
			// Draw a rectangle bubble with the baseline indicator on the right
			drawRectBubbleRightBaselineIndicator();
			break;
		case FACE_RIGHT_CENTER:
			// Draw a rectangle bubble with the center indicator on the right
			drawRectBubbleRightCenterIndicator();
			break;
		case FACE_TOP:
			// Draw a rectangle bubble with the topline indicator
			drawRectBubbleToplineIndicator();
			break;

		default:
			// No action taken for other cases
			break;
		}
	}

	// Method to draw a rectangle bubble with the topline indicator
	private void drawRectBubbleToplineIndicator() {
		getElements().addAll(new MoveTo(1.0f, 1.2f),
				new HLineTo(2.5f),
				new LineTo(2.7f, 1.0f),
				new LineTo(2.9f, 1.2f),
				new HLineTo(4.4f),
				new VLineTo(4f),
				new HLineTo(1.0f),
				new VLineTo(1.2f)
				);
	}

	// Method to draw a rectangle bubble with the baseline indicator on the right
	private void drawRectBubbleRightBaselineIndicator() {
		getElements().addAll(new MoveTo(3.0f, 1.0f),
				new HLineTo(0f),
				new VLineTo(4f),
				new HLineTo(3.0f),
				new LineTo(2.8f, 3.8f),
				new VLineTo(1f)
				);
	}

	// Method to draw a rectangle bubble with the baseline indicator on the left
	private void drawRectBubbleLeftBaselineIndicator() {
		getElements().addAll(new MoveTo(1.2f, 1.0f),
				new HLineTo(3f),
				new VLineTo(4f),
				new HLineTo(1.0f),
				new LineTo(1.2f, 3.8f),
				new VLineTo(1f)
				);
	}

	// Method to draw a rectangle bubble with the center indicator on the right
	private void drawRectBubbleRightCenterIndicator() {
		getElements().addAll(new MoveTo(3.0f, 2.5f),
				new LineTo(2.8f, 2.4f),
				new VLineTo(1f),
				new HLineTo(0f),
				new VLineTo(4f),
				new HLineTo(2.8f),
				new VLineTo(2.7f),
				new LineTo(3.0f, 2.5f)
				);
	}
	
	// Rule for drawing rectangle bubble indicator
	protected double drawRectBubbleIndicatorRule = 0.2;

	// Method to draw a rectangle bubble with the center indicator on the left
	private void drawRectBubbleLeftCenterIndicator() {
		getElements().addAll(new MoveTo(1.0f, 2.5f),
				new LineTo(1.2f, 2.4f),
				new VLineTo(1f),
				new HLineTo(2.9f),
				new VLineTo(4f),
				new HLineTo(1.2f),
				new VLineTo(2.7f),
				new LineTo(1.0f, 2.5f)
				);
	}
}