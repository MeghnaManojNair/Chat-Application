package com.messages;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;

// Message class implements Serializable for object serialization
public class Message implements Serializable {

    // String to store the name
    private String name;
    // Enum to store the type of the message
    private MessageType type;
    // String to store the message
    private String msg; 
    // Integer to store the count of online users
    private int count;
    // ArrayList to store the list of users
    private ArrayList<User> list;
    // ArrayList to store the users
    private ArrayList<User> users; 

    // Enum to store the status of the message
    private Status status;
    
    // Method to get the voice message
    public byte[] getVoiceMsg() {
        return voiceMsg;
    }

    // Byte array to store the voice message
    private byte[] voiceMsg;

    // Method to get the picture
    public String getPicture() {
        return picture;
    }

    // String to store the picture
    private String picture;

    // Default constructor
    public Message() {
    }

    // Method to get the name
    public String getName() {
        return name;
    }

    // Method to set the name
    public void setName(String name) {
        this.name = name;
    }

    // Method to get the message
    public String getMsg() {
        return msg;
    }

    // Method to set the message
    public void setMsg(String msg) {
        this.msg = msg;
    }

    // Method to get the type of the message
    public MessageType getType() {
        return type;
    }

    // Method to set the type of the message
    public void setType(MessageType type) {
        this.type = type;
    }

    // Method to get the list of users
    public ArrayList<User> getUserlist() {
        return list;
    }

    // Method to set the list of users
    public void setUserlist(HashMap<String, User> userList) {
        this.list = new ArrayList<>(userList.values());
    }

    // Method to set the count of online users
    public void setOnlineCount(int count){
        this.count = count;
    }

    // Method to get the count of online users
    public int getOnlineCount(){
        return this.count;
    }

    // Method to set the picture
    public void setPicture(String picture) {
        this.picture = picture;
    }

    // Method to get the users
    public ArrayList<User> getUsers() {
        return users;
    }

    // Method to set the users
    public void setUsers(ArrayList<User> users) {
        this.users = users;
    }

    // Method to set the status of the message
    public void setStatus(Status status) {
        this.status = status;
    }

    // Method to get the status of the message
    public Status getStatus() {
        return status;
    }

    // Method to set the voice message
    public void setVoiceMsg(byte[] voiceMsg) {
        this.voiceMsg = voiceMsg;
    }
}