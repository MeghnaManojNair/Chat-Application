
// Importing necessary packages and classes
package com.client.login;

import com.client.chatwindow.ChatController;
import com.client.chatwindow.Listener;
import com.client.util.ResizeHelper;
import javafx.application.Platform;
import javafx.beans.value.ChangeListener;
import javafx.beans.value.ObservableValue;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Cursor;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

// Controller class for the LoginView.fxml file
public class LoginController implements Initializable {
    // FXML annotations for injecting UI components
    @FXML private ImageView Defaultview;
    @FXML private ImageView Ramyaaview;
    @FXML private ImageView Koushikview;
    @FXML private ImageView Meghnaview;
    @FXML public  TextField hostnameTextfield;
    @FXML private TextField portTextfield;
    @FXML private TextField usernameTextfield;
    @SuppressWarnings("rawtypes")
    @FXML private ChoiceBox imagePicker;
    @FXML private Label selectedPicture;
    public static ChatController con;
    @FXML private BorderPane borderPane;
    private double xOffset;
    private double yOffset;
    private Scene scene;

    private static LoginController instance;

    // Singleton instance of LoginController
    public LoginController() {
        instance = this;
    }

    // Method to get singleton instance of LoginController
    public static LoginController getInstance() {
        return instance;
    }

    // Action performed when login button is clicked
    public void loginButtonAction() {
        try {
            String hostname = hostnameTextfield.getText();
            int port = Integer.parseInt(portTextfield.getText());
            String username = usernameTextfield.getText();
            String picture = selectedPicture.getText();

            FXMLLoader fmxlLoader = new FXMLLoader(getClass().getResource("/views/ChatView.fxml"));
            Parent window = (Pane) fmxlLoader.load();
            con = fmxlLoader.<ChatController>getController();
            Listener listener = new Listener(hostname, port, username, picture, con);
            Thread x = new Thread(listener);
            x.start();
            this.scene = new Scene(window);
        } catch (Exception e) {
            showErrorDialog(e.getMessage());
            e.printStackTrace();
        }
    }

    // Method to display chat scene
    public void showScene() throws IOException {
        Platform.runLater(() -> {
            Stage stage = (Stage) hostnameTextfield.getScene().getWindow();
            stage.setResizable(true);
            stage.setWidth(1040);
            stage.setHeight(620);

            stage.setOnCloseRequest((WindowEvent e) -> {
                Platform.exit();
                System.exit(0);
            });
            stage.setScene(this.scene);
            stage.setMinWidth(800);
            stage.setMinHeight(300);
            ResizeHelper.addResizeListener(stage);
            stage.centerOnScreen();
            con.setUsernameLabel(usernameTextfield.getText());
            con.setImageLabel(selectedPicture.getText());
        });
    }

    // Initializing UI components and event handlers
    @SuppressWarnings("unchecked")
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        // Setting default image picker selection
        imagePicker.getSelectionModel().selectFirst();
        selectedPicture.textProperty().bind(imagePicker.getSelectionModel().selectedItemProperty());
        selectedPicture.setVisible(false);

        // Handling border pane mouse events
        borderPane.setOnMouseDragged(event -> {
            MainLauncher.getPrimaryStage().setX(event.getScreenX() + xOffset);
            MainLauncher.getPrimaryStage().setY(event.getScreenY() + yOffset);

        });

        borderPane.setOnMousePressed(event -> {
            xOffset = MainLauncher.getPrimaryStage().getX() - event.getScreenX();
            yOffset = MainLauncher.getPrimaryStage().getY() - event.getScreenY();
            borderPane.setCursor(Cursor.CLOSED_HAND);
        });

        borderPane.setOnMouseReleased(event -> {
            borderPane.setCursor(Cursor.DEFAULT);
        });

        // Handling image picker selection change
        imagePicker.getSelectionModel().selectedItemProperty().addListener(new ChangeListener<String>() {
            @Override
            public void changed(ObservableValue<? extends String> selected, String oldPicture, String newPicture) {
                if (oldPicture != null) {
                    switch (oldPicture) {
                        case "Default":
                            Defaultview.setVisible(false);
                            break;
                        case "Koushik":
                            Koushikview.setVisible(false);
                            break;
                        case "Ramyaa":
                            Ramyaaview.setVisible(false);
                            break;
                        case "Meghna":
                            Meghnaview.setVisible(false);
                            break;
                    }
                }
                if (newPicture != null) {
                    switch (newPicture) {
                        case "Default":
                            Defaultview.setVisible(true);
                            break;
                        case "Koushik":
                            Koushikview.setVisible(true);
                            break;
                        case "Ramyaa":
                            Ramyaaview.setVisible(true);
                            break;
                        case "Meghna":
                            Meghnaview.setVisible(true);
                            break;
                    }
                }
            }
        });
    }

    /* Terminates Application */
    public void closeSystem(){
        Platform.exit();
        System.exit(0);
    }

    // Minimizes the window
    public void minimizeWindow(){
        MainLauncher.getPrimaryStage().setIconified(true);
    }

    /* This displays an alert message to the user */
    public void showErrorDialog(String message) {
        Platform.runLater(()-> {
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Warning!");
            alert.setHeaderText(message);
            alert.setContentText("Error: Server not found or invalid port number. Please try again.");
            alert.showAndWait();
        });

    }
}
