package com.client.login;

import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

// MainLauncher class extends the Application class to create a JavaFX application
public class MainLauncher extends Application {

    // Stage object to hold the primary stage of the application
    private static Stage mainStage;

    // Main method to launch the application
    public static void main(String[] args) {
        Application.launch(args);
    }

    // Overridden start method from Application class
    @Override
    public void start(Stage primaryStage) throws Exception {
        // Assigning the primary stage to the mainStage variable
        mainStage = primaryStage;
        // Setting the style of the stage as undecorated
        primaryStage.initStyle(StageStyle.UNDECORATED);
        // Making the stage non-resizable
        primaryStage.setResizable(false);

        // Loading the LoginView.fxml file to get the root node
        Parent root = FXMLLoader.load(getClass().getClassLoader().getResource("views/LoginView.fxml"));
        // Creating a scene with the root node, and width and height as 350 and 420 respectively
        Scene mainScene = new Scene(root, 350, 420);
        // Setting the scene to the primary stage
        primaryStage.setScene(mainScene);

        // Loading the application icon
        Image appIcon = new Image(getClass().getClassLoader().getResourceAsStream("images/logo.png"));
        // Adding the application icon to the primary stage
        primaryStage.getIcons().add(appIcon);

        // Setting the close request handler for the primary stage
        primaryStage.setOnCloseRequest(e -> Platform.exit());
        // Displaying the primary stage
        primaryStage.show();
    }

    // Getter method for the primary stage
    public static Stage getPrimaryStage() {
        return mainStage;
    }
}