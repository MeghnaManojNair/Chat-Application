package com.client.chatwindow;

import com.messages.User;
import javafx.geometry.Pos;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.text.Text;
import javafx.util.Callback;
import javafx.scene.text.Font;
import javafx.scene.layout.Region;

// This class is responsible for rendering each cell in the ListView for users
class CellRenderer implements Callback<ListView<User>, ListCell<User>> {
    @Override
    // This method is called to return a ListCell that can display items in the ListView
    public ListCell<User> call(ListView<User> userListView) {
        return new ListCell<User>() {
            // Create a horizontal box to hold the elements
            private HBox hBox = new HBox();
            // Text to display the user's name
            private Text userName = new Text();
            // ImageView to display the user's status
            private ImageView statusView = new ImageView();
            // ImageView to display the user's image
            private ImageView userImageView = new ImageView();
            // Regions to create gaps between the elements
            private Region gap1 = new Region();
            private Region gap2 = new Region();

            {
                // Set the font for the user's name
                userName.setFont(Font.font("Montserrat"));
                // Set the width for the gaps
                gap1.setPrefWidth(10);
                gap2.setPrefWidth(10);
                // Add all the elements to the horizontal box
                hBox.getChildren().addAll(statusView, gap1, userImageView, gap2, userName);
                // Align the elements to the left
                hBox.setAlignment(Pos.CENTER_LEFT);
            }

            @Override
            // This method is called to update the item in the cell
            protected void updateItem(User user, boolean empty) {
                super.updateItem(user, empty);
                // If the user is not null
                if (user != null) {
                    // Set the text of the userName to the user's name
                    userName.setText("   " + user.getName());

                    // Load the image for the user's status
                    Image statusImage = new Image(getClass().getClassLoader().getResource("images/" + user.getStatus().toString().toLowerCase() + ".png").toString(), 16, 16, true, true);
                    // Set the image for the statusView
                    statusView.setImage(statusImage);

                    // Load the image for the user's picture
                    Image userImage = new Image(getClass().getClassLoader().getResource("images/" + user.getPicture().toLowerCase() + ".png").toString(), 50, 50, true, true);
                    // Set the image for the userImageView
                    userImageView.setImage(userImage);

                    // Set the graphic for the cell to the horizontal box
                    setGraphic(hBox);
                } else {
                    // If the user is null, don't display anything
                    setGraphic(null);
                    setText(null);
                }
            }
        };
    }
}