package com.messages;

public enum Status {
    ONLINE, AWAY, BUSY
}
