package com.messages;

public enum MessageType {
    DISCONNECTED, CONNECTED, STATUS, USER, SERVER, NOTIFICATION, VOICE
}
